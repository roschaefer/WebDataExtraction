The following scrapers are written with Screen Scraper (http://screen-scraper.com/)

- cduniverse
- discographies
- pitchfork
- youtube

The following scrapers is written with Mozenda (http://www.mozenda.com/)

- flickr

The scrapers fetch information for a given Artist, e.g. "Madonna".

To get the Screen Scrapers running, there must be a file called INPUT.txt that contains the search string.

(Import a scraper and have a look at the *-INIT scripts to get an idea of how it works.)